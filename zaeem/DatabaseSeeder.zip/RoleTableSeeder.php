<?php

use Illuminate\Database\Seeder;

class RoleTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $r1 = new App\Role;
        $r1->name = 'admin';
        $r1->access = 0;
        $r1->save();

        $r2 = new App\Role;
        $r2->name = 'manager';
        $r2->access = 1;
        $r2->save();

        $r3 = new App\Role;
        $r3->name = 'client';
        $r3->access = 2;
        $r3->save();
    }
}
