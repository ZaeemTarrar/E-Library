<?php

use Illuminate\Database\Seeder;

class NotificationtypeTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $n1 = new App\Notificationtype;
        $n1->name = 'default';
        $n1->save();

        $n2 = new App\Notificationtype;
        $n2->name = 'success';
        $n2->save();

        $n3 = new App\Notificationtype;
        $n3->name = 'error';
        $n3->save();

        $n4 = new App\Notificationtype;
        $n4->name = 'upgrade';
        $n4->save();

        $n5 = new App\Notificationtype;
        $n5->name = 'info';
        $n5->save();
    }
}
