<?php

use Illuminate\Database\Seeder;

class UserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $u = new App\User;
        $u->name = 'Zaeem';
        $u->email = 'zaeemhassan@gmail.com';
        $u->password = bcrypt('123456');
        $u->role_id = 1;
        $u->save();
    }
}
