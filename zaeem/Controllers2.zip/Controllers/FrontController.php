<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FrontController extends Controller
{
    public function sample()
    {
        return view('front.sample');
    }

    ### Method
    ### New Method

}
