<!-- ##### All Javascript Script ##### -->
<!-- jQuery-2.2.4 js -->
<script src="{{ url('site/js/jquery/jquery-2.2.4.min.js') }}"></script>
<!-- Popper js -->
<script src="{{ url('site/js/bootstrap/popper.min.js') }}"></script>
<!-- Bootstrap js -->
<script src="{{ url('site/js/bootstrap/bootstrap.min.js') }}"></script>
<!-- All Plugins js -->
<script src="{{ url('site/js/plugins/plugins.js') }}"></script>
<!-- Active js -->
<script src="{{ url('site/js/active.js') }}"></script>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13" type="01ba78f9a4daa6f2f66a6367-text/javascript"></script>
<script type="01ba78f9a4daa6f2f66a6367-text/javascript">
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'UA-23581568-13');
</script>

<script src="https://ajax.cloudflare.com/cdn-cgi/scripts/a2bd7673/cloudflare-static/rocket-loader.min.js" data-cf-settings="01ba78f9a4daa6f2f66a6367-|49" defer=""></script>