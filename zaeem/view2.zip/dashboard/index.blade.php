

        @extends('layouts.dashboard')

        @section('content')
        
        <div class="page-header">
            <h1>
                <i class="fa fa-users"></i>
                &nbsp;
                Dashboard List
            </h1>
        </div><!-- /.page-header -->
        <div class >
            <p>
                <b>
                    Note:
                </b>
                You can add your demo text here !
            </p>
        </div>
        
        {{-- @include('shared.notification') --}}
        
         @endsection

        