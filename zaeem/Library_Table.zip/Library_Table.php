<?php

namespace App;

use Session;
use Storage;
use Auth;

class Library_Table
{
    public static function Html($html, $data)
    {
        if (is_array($data)) {
            $str = $html;
            foreach ($data as $key => $value) {
                $symbol = '!!' . $key . '!!';
                $str = str_replace($symbol, $value, $str);
            }
            return $str;
        } else {
            return str_replace("!!!!!", $data, $html);
        }
    }

    public static function Bonds($item, $value)
    {
        $myData = "";
        if (count($value) == 1) {
            $x1 = $value[0];
            $myData .= $item->$x1;
        } elseif (count($value) == 2) {
            $x1 = $value[0];
            $x2 = $value[1];
            $myData .= $item->$x1->$x2;
        } elseif (count($value) == 3) {
            $x1 = $value[0];
            $x2 = $value[1];
            $x3 = $value[2];
            $myData .= $item->$x1->$x2->$x3;
        } elseif (count($value) == 4) {
            $x1 = $value[0];
            $x2 = $value[1];
            $x3 = $value[2];
            $x4 = $value[3];
            $myData .= $item->$x1->$x2->$x3->$x4;
        } elseif (count($value) == 5) {
            $x1 = $value[0];
            $x2 = $value[1];
            $x3 = $value[2];
            $x4 = $value[3];
            $x5 = $value[4];
            $myData .= $item->$x1->$x2->$x3->$x4->$x5;
        } elseif (count($value) == 6) {
            $x1 = $value[0];
            $x2 = $value[1];
            $x3 = $value[2];
            $x4 = $value[3];
            $x5 = $value[4];
            $x6 = $value[5];
            $myData .= $item->$x1->$x2->$x3->$x4->$x5->$x6;
        } else { }
        return $myData;
    }

    public static function Table($crud, $title, $edit, $del, $headers, $list, $tdlist)
    {
        $str = '';
        $str .= '<div class="col-xs-12">
        <div class="table-header">
            ' . $title . '
        </div>

        <div>
            <div class="dataTables_wrapper form-inline no-footer"><div class="row"><div class="col-xs-6"><div class="dataTables_length" id="dynamic-table_length"><label>Display <select name="dynamic-table_length" aria-controls="dynamic-table" class="form-control input-sm"><option value="10">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select> records</label></div></div><div class="col-xs-6"><div id="dynamic-table_filter" class="dataTables_filter"><label>Search:<input type="search" class="form-control input-sm" placeholder="" aria-controls="dynamic-table"></label></div></div></div><table id="dynamic-table" class="table table-striped table-bordered table-hover dataTable no-footer" role="grid" aria-describedby="dynamic-table_info">
                    <thead class="thin-border-bottom">
                            <tr>';


        foreach ($headers as $key => $value) {
            $str .= '<th>' . ucfirst($value) . '</th>';
        }

        $str .= '<th> Actions </th>';

        $str .= '</tr>
                        </thead>
                

                        <tbody>';
        // loop through the List of model table
        foreach ($list as $item) {
            $str .= '<tr>';

            // loop through specific Td whinch we look forward to display
            foreach ($tdlist as $key => $val) {
                $str .= '<td>';

                // setting
                $html = "!!!!!";
                $myData;
                $value;

                // array first level checks
                if (is_array($val)) {
                    if (isset($val['html'])) {
                        $html = $val['html'];
                        $value = $val['data'];
                        $myData = [];
                        if (is_array($value[0])) {
                            $myData = [];
                            foreach ($value as $k => $v) {
                                $myData[] = Library_Table::Bonds($item, $v);
                            }
                        } else {
                            $myData = '';
                            $myData = Library_Table::Bonds($item, $value);
                        }
                        $str .= Library_Table::Html($html, $myData);
                    } elseif (isset($val['data'])) {
                        $value = $val['data'];
                        $myData = '';
                        $myData = Library_Table::Bonds($item, $value);
                        $str .= Library_Table::Html($html, $myData);
                    } else {
                        foreach ($val as $k => $v) {
                            if (isset($v['html'])) {
                                $html = $v['html'];
                                $v2 = $v['data'];
                                $myData = [];
                                if (is_array($v2[0])) {
                                    $myData = [];
                                    foreach ($v2 as $k1 => $v1) {
                                        $myData[] = Library_Table::Bonds($item, $v1);
                                    }
                                } else {
                                    $myData = '';
                                    $myData = Library_Table::Bonds($item, $v2);
                                }
                                $str .= Library_Table::Html($html, $myData);
                            } elseif (isset($v['data'])) {
                                $v2 = $v['data'];
                                $myData = '';
                                $myData = Library_Table::Bonds($item, $v2);
                                $str .= Library_Table::Html($html, $myData);
                            }
                        }
                    }
                } else {
                    echo 'You are not  Passing an Array in Table Library ! ';
                    exit;
                }

                $str .= '</td>';
            }

            $str .= '<td>';

            if ($edit) {
                $str .= ' <a href="' . route($crud . '.edit', ['id' => $item->id]) . '" class="btn btn-primary btn-xs">
            <i class="fa fa-pencil"></i>
        </a> ';
            }

            if ($del) {
                $str .= ' <form class="inline" action="' . route($crud . '.destroy', ['id' => $item->id]) . '" method="post" >
            ' . csrf_field() . '
              <input type="hidden" name="_method" value="delete" >
              <div>
                  <button type="submit" class="btn btn-danger btn-xs" >
                      <i class="fa fa-trash" ></i>
                  </button>
              </div>
        </form> ';
            }

            $str .= '</td>';

            $str .= '</tr>';
        }
        $str .= '</tbody>
            </table><div class="row">
            <div class="col-xs-6"><div class="dataTables_info" id="dynamic-table_info" role="status" aria-live="polite">Showing 1 to 10 of 23 entries</div></div><div class="col-xs-6"><div class="dataTables_paginate paging_simple_numbers" id="dynamic-table_paginate"><ul class="pagination"><li class="paginate_button previous disabled" aria-controls="dynamic-table" tabindex="0" id="dynamic-table_previous"><a href="#">Previous</a></li><li class="paginate_button active" aria-controls="dynamic-table" tabindex="0"><a href="#">1</a></li><li class="paginate_button " aria-controls="dynamic-table" tabindex="0"><a href="#">2</a></li><li class="paginate_button " aria-controls="dynamic-table" tabindex="0"><a href="#">3</a></li><li class="paginate_button next" aria-controls="dynamic-table" tabindex="0" id="dynamic-table_next"><a href="#">Next</a></li></ul></div></div></div></div>
        </div>
    </div>

';

        return $str;
    }
}
