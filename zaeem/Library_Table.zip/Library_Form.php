<?php


namespace App;

use Session;
use Auth;

class Library_Form
{
    public static function field($name, $name2, $errors, $placeholder, $type)
    {
        // print_r($errors) ;
        // exit;
        $str = '';
        $str .= '<div class="form-group ' . ($errors->has($name) ? 'has-error' : '') . '">
        <label class="col-sm-3 control-label no-padding-right" > ' . $name2 . ' </label>
        <div class="col-sm-9">
            <input type="' . (($type == "") ? 'text' : $type) . '" id="form-field-1" placeholder="' . $placeholder . '" name="' . $name . '"
            value="' . (Session::has($name) ? Session::get($name) : '') . '" class="col-xs-10 col-sm-5">';

        if ($errors->has($name)) {
            $str .= '<br>
                <div class="block text-danger" >
                    <br>
                    <b> Error ! </b>
                    <p>
                         ' . ($errors->first($name)) . '
                    </p>
                </div>';
        }

        $str .= '</div>
        </div>';

        return $str;
    }

    public static function select($name, $name2, $list, $none)
    {
        // print_r($errors) ;
        // exit;
        $str = '';

        $str .= '<div class="form-group">
        <label class="col-sm-3 control-label no-padding-right" > ' . ucfirst($name2) . ' </label>
        <div class="col-sm-9">
            <select  placeholder="" name="' . $name . '" class="col-xs-10 col-sm-5">';

        if ($none) {
            $str .= '<option value="">None</option>';
        }

        foreach ($list as $item) {
            if (Session::has($name) && Session::get($name) == $item->id) {
                $str .= '<option selected value="' . $item->id . '">' . ucfirst($item->name) . '</option>';
            } else {
                $str .= '<option value="' . $item->id . '">' . ucfirst($item->name) . '</option>';
            }
        }

        $str .= '</select>
                </div>
            </div>';

        return $str;
    }
}
