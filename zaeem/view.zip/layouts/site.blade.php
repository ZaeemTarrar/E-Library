<!DOCTYPE html>
<html lang="en">

@include('inc.head')

<body>

    @include('inc.mainmenu')

    @yield('samaan')

    @include('inc.footer')

    @include('inc.foot')

</body>

</html>